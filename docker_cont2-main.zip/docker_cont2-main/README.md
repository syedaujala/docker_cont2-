# docker_cont2
Todo App using fast api and docker 
